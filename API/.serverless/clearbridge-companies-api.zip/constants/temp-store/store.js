const companies = [];
module.exports = {
    companies
}
